const mongoose = require('mongoose');

const Filme = new mongoose.Schema({
    titulo: {
        type: String,
        required: true
    },
    ano: {
        type: String,
        required: true
    }
});

mongoose.model('filme', Filme);