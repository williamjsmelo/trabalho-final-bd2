const express = require('express');
const sqlite3 = require('sqlite3');

const routesSqlite = express.Router();

const db = new sqlite3.Database('./database/db.sqlite3', (err) => {
    if(err){
        console.log("A conexão com o sqlite3 falhou!");
        console.log(err.message);
    }
    else
        console.log("Conectou ao sqlite3 com  sucesso!");

});


//Cadastrar
routesSqlite.post("/usuario", (req, res) => {
    db.run("INSERT INTO users (usuario, senha, root) VALUES(?, ?, ?)", req.body.usuario, req.body.senha, 0, (err) => {
        if(err){
            console.log(err.message);
            return res.status(400).json("O usário não foi cadastrado!");
        }
        else
            return res.json("Usuário cadastrado com sucesso");        
    });
});

//index
routesSqlite.get("/usuario", (req, res) => {
    db.all("SELECT * FROM users", (err, row) => {
        if(err){
            console.log(err.message);
            return res.status(400).json("Nenhum usuário encontrado!");
        }
        else
            return res.json(row);
    });
});

//show
routesSqlite.get("/usuario/:usuario", (req, res) => {
    db.get("SELECT * FROM users WHERE usuario = ?", req.params.usuario, (err, row) => {
        if(err){
            console.log(err.message);
            return res.status(400).json("Usuário não encontrado");
        }
        else
            return res.json(row);
    });
});

//Remover
routesSqlite.delete("/usuario/:usuario", (req, res) => {
    db.run("DELETE FROM users WHERE usuario = ?", req.params.usuario, (err) => {
        if(err){
            console.log(err.message);
            return res.status(400).json("Nenhum usuário foi removido!");
        }
        else
            return res.json("Usuário removido com sucesso"); 
    });
});

module.exports = routesSqlite;

