const express = require('express');
const mongoose = require('mongoose');

const routesMongo = express.Router();

require("../models/Filme");
const Filme = mongoose.model('filme');

mongoose.connect('mongodb://localhost:27017/bancofilmes', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("Conexão com MongoDB realizada com sucesso!");
}).catch((erro) => {
    console.log("Erro: Conexão com MongoDB não foi realizada com sucesso!");
});


routesMongo.get("/filme", (req, res) => {
    Filme.find({}).then((filme) => {
        return res.json(filme);
    }).catch((erro) => {
        return res.status(400).json({
            error: true,
            message: "Nenhum filme encontrado!"
        })
    })
});

routesMongo.get("/filme/:titulo", (req, res) => {
    Filme.findOne({ titulo: req.params.titulo }).then((filme) => {
        return res.json(filme);
    }).catch((erro) => {
        return res.status(400).json({
            error: true,
            message: "Nenhum filme encontrado!"
        })
    })
})

routesMongo.post("/filme", (req, res) => {
    const filme = Filme.create(req.body, (err) => {
        if (err) return res.status(400).json({
            error: true,
            message: "Error: Filme não foi cadastrado com sucesso!"
        });

        return res.status(200).json({
            error: false,
            message: "Filme cadastrado com sucesso!"
        })
    });
});

routesMongo.put("/filme/:titulo", (req, res) => {
    const filme = Filme.updateOne({ titulo: req.params.titulo}, req.body, (err) => {
        if(err) return res.status(400).json({
            error: true,
            message: "Error: Filme não foi editado com sucesso!"
        });

        return res.json({
            error: false,
            message: "Filme editado com sucesso!"
        });
    });
});

routesMongo.delete("/filme/:titulo", (req, res) => {
    const filme = Filme.deleteOne({titulo: req.params.titulo}, (err) => {
        if(err) return res.status(400).json({
            error: true,
            message: "Error: Filme não foi apagado com sucesso!"
        });

        return res.json({
            error: false,
            message: "Filme apagado com sucesso!"
        });
    });
});

module.exports = routesMongo;