const express = require('express');
const cors = require('cors');

const mongoRoutes = require("./routes/mongoRoutes");

const sqliteRoutes = require("./routes/sqliteRoutes");

const app = express();

app.use(express.json());

app.use((req, res, next) => {
    //console.log("Acessou o Middleware!");
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", 'GET,PUT,POST,DELETE');
    app.use(cors());
    app.use(mongoRoutes);
    app.use(sqliteRoutes);
    next();
});






app.listen(3001, () => {
    console.log("Servidor iniciado na porta 3001: http://localhost:3001/");
});