import React from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';

import { useHistory } from 'react-router-dom';
import { useState } from "react";
import api from '../services/api';

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));


export default function Controle() {
  const history = useHistory();
  
  //Funções dos usuários
  function clickListaUsuario(e) {
        e.preventDefault();
        history.push('/controle/listarusuario');
    }

    function clickDeletaUsuario(e){
        e.preventDefault();
        history.push('/controle/removeusuario');
    }

    //Funções dos filmes
    function clickListaFilme(e){
        e.preventDefault();
        history.push('/controle/listarfilme');
    }

    function clickShowFilme(e){
        e.preventDefault();
        history.push('/controle/procurarfilme');
    }

    function clickAdicionaFilme(e){
        e.preventDefault();
        history.push('/controle/adicionarfilme');
    }

    function clickRemoveFilme(e){
        e.preventDefault();
        history.push('/controle/removerfilme');
    }

    function clickEditaFilme(e){
        e.preventDefault();
        history.push('/controle/editarfilme');
    }


  const classes = useStyles();

  return (
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      <div className={classes.paper}>
        <Avatar className={classes.avatar}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          Usuários
        </Typography>
        <form className={classes.form} noValidate>
          <Button onClick={clickListaUsuario}
            type="button"
            name="listaUsuario"
            fullWidth
            variant="contained"
            color="primary"
          >
            Ver usuários
          </Button>
          ⠀⠀⠀⠀⠀⠀⠀⠀
          <Button onClick={clickDeletaUsuario}
            type="button"
            name="deletaUsuario"
            fullWidth
            variant="contained"
            color="primary"
          >
            Excluir usuário
          </Button>
          ⠀⠀⠀⠀⠀⠀⠀⠀
        </form>
        <Typography component="h1" variant="h5">
          Filmes
        </Typography>
        <Button onClick={clickListaFilme}
            type="button"
            name="listaFilme"
            fullWidth
            variant="contained"
            color="primary"
          >
            Listar filmes
          </Button>
          ⠀⠀⠀⠀⠀⠀⠀⠀
          <Button onClick={clickShowFilme}
            type="button"
            name="showFilme"
            fullWidth
            variant="contained"
            color="primary"
          >
            Procurar filme
          </Button>
          ⠀⠀⠀⠀⠀⠀⠀⠀
          <Button onClick={clickAdicionaFilme}
            type="button"
            name="adicionaFilme"
            fullWidth
            variant="contained"
            color="primary"
          >
            Adicionar filme
          </Button>
          ⠀⠀⠀⠀⠀⠀⠀⠀
          <Button onClick={clickRemoveFilme}
            type="button"
            name="removeFilme"
            fullWidth
            variant="contained"
            color="primary"
          >
            Remover filme
          </Button>
          ⠀⠀⠀⠀⠀⠀⠀⠀
          <Button onClick={clickEditaFilme}
            type="button"
            name="editaFilme"
            fullWidth
            variant="contained"
            color="primary"
          >
            Editar filme
          </Button>
          ⠀⠀⠀⠀⠀⠀⠀
          <Grid container>
            <Grid item xs>
              <Link href="/" variant="body2">
                  {"Sair"}
              </Link>
            </Grid>
            <Grid item>
              <Link href="#" variant="body2">
              </Link>
            </Grid>
          </Grid>
      </div>
    </Container>
  );
}
