import React from 'react';
import Link from '@material-ui/core/Link';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Title from '../component/Title';

import { useHistory } from 'react-router-dom';
import api from '../services/api';

var rows = [];

api.get('/usuario').then(response => {
    console.log(response.data);
    rows = response.data;
});


const useStyles = makeStyles((theme) => ({
  seeMore: {
    marginTop: theme.spacing(3),
  },
}));

export default function ListarUsuarios() {
    const history = useHistory();

    function preventDefault(event) {
    event.preventDefault();
    history.push('/controle');
    }


  const classes = useStyles();

  return (
    <React.Fragment>
      <Title>Usuários</Title>
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell>Usuário</TableCell>
            <TableCell>Senha</TableCell>
            <TableCell>Categoria</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.usuario}>
              <TableCell>{row.usuario}</TableCell>
              <TableCell>{row.senha}</TableCell>
              <TableCell>{row.root}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <div className={classes.seeMore}>
        <Link color="primary" onClick={preventDefault}>
          Voltar
        </Link>
      </div>
    </React.Fragment>
  );
}
