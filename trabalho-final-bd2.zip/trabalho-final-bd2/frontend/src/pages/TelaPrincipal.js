import React from 'react';
import Link from '@material-ui/core/Link';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Title from '../component/Title';

import { useHistory } from 'react-router-dom';
import api from '../services/api';

var rows = [];

api.get('/filme').then(response => {
    console.log(response.data);
    rows = response.data;
});


const useStyles = makeStyles((theme) => ({
  seeMore: {
    marginTop: theme.spacing(3),
  },
}));

export default function TelaPrincipal() {
    const history = useHistory();

    function preventDefault(event) {
    event.preventDefault();
    history.push('/');
    }


  const classes = useStyles();

  return (
    <React.Fragment>
      <Title>Filmes</Title>
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell>Título</TableCell>
            <TableCell>Ano</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.titulo}>
              <TableCell>{row.titulo}</TableCell>
              <TableCell>{row.ano}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <div className={classes.seeMore}>
        <Link color="primary" onClick={preventDefault}>
          Sair
        </Link>
      </div>
    </React.Fragment>
  );
}
