import React from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';

import { useHistory } from 'react-router-dom';
import { useState } from "react";
import api from '../services/api';
import { RepeatOneSharp } from '@material-ui/icons';

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

const initialValue = {
  titulo: '',
}

export default function ProcurarFilme() {
  const [values, setValues] = useState(initialValue);
  const history = useHistory();

  function onChange(event) {
    const { name, value } = event.target;

    setValues({ ...values, [name]: value });
  }

  function handleSubmit(event) {
    event.preventDefault();

    api.get('filme/'+values.titulo).then(response => {
      console.log("A comunicação com o backend funcionou!");
    
      if(values.titulo === response.data.titulo){
        alert("Título: "+response.data.titulo+" | Ano: "+response.data.ano);
      }
    }).catch(response => {
      alert('Filme não encontrado');
    });


    //history.push('/');
  } 


  
  const classes = useStyles();

  return (
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      <div className={classes.paper}>
        <Avatar className={classes.avatar}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          Procurar filme
        </Typography>
        <form onSubmit={handleSubmit} className={classes.form} noValidate>
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="titulo"
            label="Título do filme"
            name="titulo"
            onChange={onChange}
            autoComplete="titulo"
            autoFocus
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
          >
            Procurar
          </Button>
          <Grid container>
            <Grid item xs>
              <Link href="/controle" variant="body2">
                  {"Voltar"}
              </Link>
            </Grid>
            <Grid item>
              <Link href="/" variant="body2">
                {"Sair"}
              </Link>
            </Grid>
          </Grid>
        </form>
      </div>
    </Container>
  );
}
