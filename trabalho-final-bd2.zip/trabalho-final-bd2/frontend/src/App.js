import { BrowserRouter, Switch, Route } from 'react-router-dom';

import Login from './pages/SignIn';
import Cadastro from './pages/SignUp';
import Controle from './pages/Controle';
import RemoveUsuario from './pages/RemoveUsuario';
import AdicionarFilme from './pages/AdicionarFilme';
import RemoveFilme from './pages/RemoverFilme';
import EditarFilme from './pages/EditarFilme';
import ProcurarFilme from './pages/ProcurarFilmes';
import ListarFilmes from './pages/ListarFilmes';
import TelaPrincipal from './pages/TelaPrincipal';
import ListarUsuarios from './pages/ListarUsuarios';

function App() {
  return (
      <BrowserRouter>
          <Switch>
              <Route path="/" exact component={Login} />
              <Route path="/cadastro" exact component={Cadastro} />
              <Route path="/controle" exact component={Controle} />
              <Route path="/controle/removeusuario" exact component={RemoveUsuario} />
              <Route path="/controle/adicionarfilme" exact component={AdicionarFilme} />
              <Route path="/controle/removerfilme" exact component={RemoveFilme} />
              <Route path="/controle/editarfilme" exact component={EditarFilme} />
              <Route path="/controle/procurarfilme" exact component={ProcurarFilme} />
              <Route path="/controle/listarfilme" exact component={ListarFilmes} />
              <Route path="/controle/listarusuario" exact component={ListarUsuarios} />
              <Route path="/telaprincipal" exact component={TelaPrincipal} />
          </Switch>
      </BrowserRouter>
  );
}

export default App;
//<Route path="/cadastro" component={Cadastro} />